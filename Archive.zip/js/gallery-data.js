// Auto-generated at 2025-04-25T14:18:10.401Z
const galleryData = [
  {
    src: "assets/images/nature/Nature-1.jpg",
    thumb: "assets/images/nature/thumbs/Nature-1.jpg",
    category: "nature",
    title: "Nature 1"
  },
  {
    src: "assets/images/nature/Nature-10.jpg",
    thumb: "assets/images/nature/thumbs/Nature-10.jpg",
    category: "nature",
    title: "Nature 10"
  },
  {
    src: "assets/images/nature/Nature-2.jpg",
    thumb: "assets/images/nature/thumbs/Nature-2.jpg",
    category: "nature",
    title: "Nature 2"
  },
  {
    src: "assets/images/nature/Nature-3.jpg",
    thumb: "assets/images/nature/thumbs/Nature-3.jpg",
    category: "nature",
    title: "Nature 3"
  },
  {
    src: "assets/images/nature/Nature-4.jpg",
    thumb: "assets/images/nature/thumbs/Nature-4.jpg",
    category: "nature",
    title: "Nature 4"
  },
  {
    src: "assets/images/nature/Nature-5.jpg",
    thumb: "assets/images/nature/thumbs/Nature-5.jpg",
    category: "nature",
    title: "Nature 5"
  },
  {
    src: "assets/images/nature/Nature-6.jpg",
    thumb: "assets/images/nature/thumbs/Nature-6.jpg",
    category: "nature",
    title: "Nature 6"
  },
  {
    src: "assets/images/nature/Nature-7.JPG",
    thumb: "assets/images/nature/thumbs/Nature-7.JPG",
    category: "nature",
    title: "Nature 7"
  },
  {
    src: "assets/images/nature/Nature-8.jpg",
    thumb: "assets/images/nature/thumbs/Nature-8.jpg",
    category: "nature",
    title: "Nature 8"
  },
  {
    src: "assets/images/nature/Nature-9.jpg",
    thumb: "assets/images/nature/thumbs/Nature-9.jpg",
    category: "nature",
    title: "Nature 9"
  },
  {
    src: "assets/images/portrait/Portrait-1.jpg",
    thumb: "assets/images/portrait/thumbs/Portrait-1.jpg",
    category: "portrait",
    title: "Portrait 1"
  },
  {
    src: "assets/images/portrait/Portrait-2.jpg",
    thumb: "assets/images/portrait/thumbs/Portrait-2.jpg",
    category: "portrait",
    title: "Portrait 2"
  },
  {
    src: "assets/images/portrait/Portrait-3.JPG",
    thumb: "assets/images/portrait/thumbs/Portrait-3.JPG",
    category: "portrait",
    title: "Portrait 3"
  },
  {
    src: "assets/images/landscape/Landscape-1.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-1.jpg",
    category: "landscape",
    title: "Landscape 1"
  },
  {
    src: "assets/images/landscape/Landscape-2.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-2.jpg",
    category: "landscape",
    title: "Landscape 2"
  },
  {
    src: "assets/images/landscape/Landscape-3.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-3.jpg",
    category: "landscape",
    title: "Landscape 3"
  },
  {
    src: "assets/images/landscape/Landscape-4.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-4.jpg",
    category: "landscape",
    title: "Landscape 4"
  },
  {
    src: "assets/images/landscape/Landscape-5.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-5.jpg",
    category: "landscape",
    title: "Landscape 5"
  },
  {
    src: "assets/images/landscape/Landscape-6.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-6.jpg",
    category: "landscape",
    title: "Landscape 6"
  },
  {
    src: "assets/images/landscape/Landscape-7.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-7.jpg",
    category: "landscape",
    title: "Landscape 7"
  },
  {
    src: "assets/images/landscape/Landscape-8.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-8.jpg",
    category: "landscape",
    title: "Landscape 8"
  },
  {
    src: "assets/images/landscape/Landscape-9.jpg",
    thumb: "assets/images/landscape/thumbs/Landscape-9.jpg",
    category: "landscape",
    title: "Landscape 9"
  },
  {
    src: "assets/images/city/City-1.jpg",
    thumb: "assets/images/city/thumbs/City-1.jpg",
    category: "city",
    title: "City 1"
  },
  {
    src: "assets/images/city/City-10.jpg",
    thumb: "assets/images/city/thumbs/City-10.jpg",
    category: "city",
    title: "City 10"
  },
  {
    src: "assets/images/city/City-11.jpg",
    thumb: "assets/images/city/thumbs/City-11.jpg",
    category: "city",
    title: "City 11"
  },
  {
    src: "assets/images/city/City-12.jpg",
    thumb: "assets/images/city/thumbs/City-12.jpg",
    category: "city",
    title: "City 12"
  },
  {
    src: "assets/images/city/City-13.jpg",
    thumb: "assets/images/city/thumbs/City-13.jpg",
    category: "city",
    title: "City 13"
  },
  {
    src: "assets/images/city/City-14.jpg",
    thumb: "assets/images/city/thumbs/City-14.jpg",
    category: "city",
    title: "City 14"
  },
  {
    src: "assets/images/city/City-15.jpg",
    thumb: "assets/images/city/thumbs/City-15.jpg",
    category: "city",
    title: "City 15"
  },
  {
    src: "assets/images/city/City-16.jpg",
    thumb: "assets/images/city/thumbs/City-16.jpg",
    category: "city",
    title: "City 16"
  },
  {
    src: "assets/images/city/City-17.jpg",
    thumb: "assets/images/city/thumbs/City-17.jpg",
    category: "city",
    title: "City 17"
  },
  {
    src: "assets/images/city/City-18.jpg",
    thumb: "assets/images/city/thumbs/City-18.jpg",
    category: "city",
    title: "City 18"
  },
  {
    src: "assets/images/city/City-19.jpg",
    thumb: "assets/images/city/thumbs/City-19.jpg",
    category: "city",
    title: "City 19"
  },
  {
    src: "assets/images/city/City-2.jpg",
    thumb: "assets/images/city/thumbs/City-2.jpg",
    category: "city",
    title: "City 2"
  },
  {
    src: "assets/images/city/City-20.jpg",
    thumb: "assets/images/city/thumbs/City-20.jpg",
    category: "city",
    title: "City 20"
  },
  {
    src: "assets/images/city/City-21.jpg",
    thumb: "assets/images/city/thumbs/City-21.jpg",
    category: "city",
    title: "City 21"
  },
  {
    src: "assets/images/city/City-22.jpg",
    thumb: "assets/images/city/thumbs/City-22.jpg",
    category: "city",
    title: "City 22"
  },
  {
    src: "assets/images/city/City-23.jpg",
    thumb: "assets/images/city/thumbs/City-23.jpg",
    category: "city",
    title: "City 23"
  },
  {
    src: "assets/images/city/City-24.jpg",
    thumb: "assets/images/city/thumbs/City-24.jpg",
    category: "city",
    title: "City 24"
  },
  {
    src: "assets/images/city/City-25.jpg",
    thumb: "assets/images/city/thumbs/City-25.jpg",
    category: "city",
    title: "City 25"
  },
  {
    src: "assets/images/city/City-26.jpg",
    thumb: "assets/images/city/thumbs/City-26.jpg",
    category: "city",
    title: "City 26"
  },
  {
    src: "assets/images/city/City-27.jpg",
    thumb: "assets/images/city/thumbs/City-27.jpg",
    category: "city",
    title: "City 27"
  },
  {
    src: "assets/images/city/City-28.jpg",
    thumb: "assets/images/city/thumbs/City-28.jpg",
    category: "city",
    title: "City 28"
  },
  {
    src: "assets/images/city/City-29.jpg",
    thumb: "assets/images/city/thumbs/City-29.jpg",
    category: "city",
    title: "City 29"
  },
  {
    src: "assets/images/city/City-3.jpg",
    thumb: "assets/images/city/thumbs/City-3.jpg",
    category: "city",
    title: "City 3"
  },
  {
    src: "assets/images/city/City-4.jpg",
    thumb: "assets/images/city/thumbs/City-4.jpg",
    category: "city",
    title: "City 4"
  },
  {
    src: "assets/images/city/City-5.jpg",
    thumb: "assets/images/city/thumbs/City-5.jpg",
    category: "city",
    title: "City 5"
  },
  {
    src: "assets/images/city/City-6.jpg",
    thumb: "assets/images/city/thumbs/City-6.jpg",
    category: "city",
    title: "City 6"
  },
  {
    src: "assets/images/city/City-7.jpg",
    thumb: "assets/images/city/thumbs/City-7.jpg",
    category: "city",
    title: "City 7"
  },
  {
    src: "assets/images/city/City-8.jpg",
    thumb: "assets/images/city/thumbs/City-8.jpg",
    category: "city",
    title: "City 8"
  },
  {
    src: "assets/images/city/City-9.jpg",
    thumb: "assets/images/city/thumbs/City-9.jpg",
    category: "city",
    title: "City 9"
  },
  {
    src: "assets/images/film/Film-1.jpg",
    thumb: "assets/images/film/thumbs/Film-1.jpg",
    category: "film",
    title: "Film 1"
  },
  {
    src: "assets/images/film/Film-10.jpg",
    thumb: "assets/images/film/thumbs/Film-10.jpg",
    category: "film",
    title: "Film 10"
  },
  {
    src: "assets/images/film/Film-11.jpg",
    thumb: "assets/images/film/thumbs/Film-11.jpg",
    category: "film",
    title: "Film 11"
  },
  {
    src: "assets/images/film/Film-12.jpg",
    thumb: "assets/images/film/thumbs/Film-12.jpg",
    category: "film",
    title: "Film 12"
  },
  {
    src: "assets/images/film/Film-13.jpg",
    thumb: "assets/images/film/thumbs/Film-13.jpg",
    category: "film",
    title: "Film 13"
  },
  {
    src: "assets/images/film/Film-14.jpg",
    thumb: "assets/images/film/thumbs/Film-14.jpg",
    category: "film",
    title: "Film 14"
  },
  {
    src: "assets/images/film/Film-15.jpg",
    thumb: "assets/images/film/thumbs/Film-15.jpg",
    category: "film",
    title: "Film 15"
  },
  {
    src: "assets/images/film/Film-2.jpg",
    thumb: "assets/images/film/thumbs/Film-2.jpg",
    category: "film",
    title: "Film 2"
  },
  {
    src: "assets/images/film/Film-3.jpg",
    thumb: "assets/images/film/thumbs/Film-3.jpg",
    category: "film",
    title: "Film 3"
  },
  {
    src: "assets/images/film/Film-4.jpg",
    thumb: "assets/images/film/thumbs/Film-4.jpg",
    category: "film",
    title: "Film 4"
  },
  {
    src: "assets/images/film/Film-5.jpg",
    thumb: "assets/images/film/thumbs/Film-5.jpg",
    category: "film",
    title: "Film 5"
  },
  {
    src: "assets/images/film/Film-6.jpg",
    thumb: "assets/images/film/thumbs/Film-6.jpg",
    category: "film",
    title: "Film 6"
  },
  {
    src: "assets/images/film/Film-7.jpg",
    thumb: "assets/images/film/thumbs/Film-7.jpg",
    category: "film",
    title: "Film 7"
  },
  {
    src: "assets/images/film/Film-8.jpg",
    thumb: "assets/images/film/thumbs/Film-8.jpg",
    category: "film",
    title: "Film 8"
  },
  {
    src: "assets/images/film/Film-9.jpg",
    thumb: "assets/images/film/thumbs/Film-9.jpg",
    category: "film",
    title: "Film 9"
  },
  {
    src: "assets/images/bw/B&W-1.JPG",
    thumb: "assets/images/bw/thumbs/B&W-1.JPG",
    category: "bw",
    title: "B&W 1"
  },
  {
    src: "assets/images/bw/B&W-2.JPG",
    thumb: "assets/images/bw/thumbs/B&W-2.JPG",
    category: "bw",
    title: "B&W 2"
  },
  {
    src: "assets/images/bw/B&W-3.JPG",
    thumb: "assets/images/bw/thumbs/B&W-3.JPG",
    category: "bw",
    title: "B&W 3"
  },
  {
    src: "assets/images/bw/B&W-4.JPG",
    thumb: "assets/images/bw/thumbs/B&W-4.JPG",
    category: "bw",
    title: "B&W 4"
  },
  {
    src: "assets/images/bw/B&W-5.JPG",
    thumb: "assets/images/bw/thumbs/B&W-5.JPG",
    category: "bw",
    title: "B&W 5"
  },
  {
    src: "assets/images/bw/B&W-6.JPG",
    thumb: "assets/images/bw/thumbs/B&W-6.JPG",
    category: "bw",
    title: "B&W 6"
  },
  {
    src: "assets/images/bw/B&W-7.JPG",
    thumb: "assets/images/bw/thumbs/B&W-7.JPG",
    category: "bw",
    title: "B&W 7"
  },
];

export default galleryData;